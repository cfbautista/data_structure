package com.company;

public class EmployeeLinkedList {

    private EmployeeNode head;
//    private int size;
//
    public void addToFront(Employee employee) {
        EmployeeNode node = new EmployeeNode(employee);
        node.setNext(head);//set the CURRENT nodes NEXT field * INSERTING the node right in front of the LIST
        head = node;
        //size++;
    }

    //Midterm Assignment create a method for removing the node on the front

    public void printList() {
        EmployeeNode current = head;//setting the head as the current node
        System.out.print("HEAD -> ");
        while (current != null) { // set until current is not equal to null
            System.out.print(current);
            System.out.print(" -> ");
            current = current.getNext();//move to the next node
        }
        System.out.println("null");
    }

}
