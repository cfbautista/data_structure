package com.company;


public class Main {

    public static void main(String[] args) {

        Employee janeJones = new Employee("Francis", "Magalona", 123);
        Employee johnDoe = new Employee("Rolly", "Ok", 4567);
        Employee marySmith = new Employee("Chester", "Bautista", 22);
        Employee mikeWilson = new Employee("Aries", "GO", 3245);

        EmployeeLinkedList list = new EmployeeLinkedList();

        list.addToFront(janeJones);
        list.addToFront(johnDoe);
        list.addToFront(marySmith);
        list.addToFront(mikeWilson);


        list.printList();

        //Midterm Assignment call the  method that removes front node from the list


    }
}
